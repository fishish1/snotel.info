COMMERCIAL LICENSE

Copyright (c) 2019-2020 Sideway Inc.

This package requires a commercial license. You may not use, copy, or distribute it without first acquiring a commercial license from Sideway Inc. Using this software without a license is a violation of US and international law. To obtain a license, please contact [sales@sideway.com](mailto:sales@sideway.com).

This package contains code previously published under an open source license. You can find the previous materials and the terms under which they were originally published at: [https://github.com/hapijs/hoek/blob/master/LICENSE](https://github.com/hapijs/hoek/blob/master/LICENSE).
